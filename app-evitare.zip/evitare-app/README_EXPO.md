# Evitare® App — Guía de pruebas con Expo y despliegue

## Opción A: Probar en tu celular AHORA (Expo + Web)

La app actual es React Web. Para probarla en tu teléfono sin instalar nada:

### Con Vercel (recomendado):
1. Sube a GitHub → conecta Vercel → agrega variables de entorno
2. Abre la URL en tu celular — funciona perfectamente en mobile

### Con Expo Web local:
```bash
npm install
npm run dev
# Abre el QR en tu celular desde la misma red WiFi
```

---

## Opción B: App nativa con Expo Go (para Android/iOS)

Para convertir a React Native y probar con Expo Go:

### 1. Instalar Expo
```bash
npm install -g expo-cli
npx create-expo-app evitare-native --template blank-typescript
cd evitare-native
```

### 2. Instalar dependencias clave
```bash
npx expo install expo-router react-native-safe-area-context react-native-screens
npx expo install @supabase/supabase-js
npx expo install expo-secure-store
```

### 3. Probar en tu celular
```bash
npx expo start
# Escanea el QR con la app "Expo Go" en tu celular
```

---

## Opción C: APK para Play Store (siguiente paso)

```bash
# Instalar EAS Build
npm install -g eas-cli
eas login
eas build:configure

# Generar APK de prueba (Android)
eas build --platform android --profile preview

# Generar AAB para Play Store (producción)
eas build --platform android --profile production
```

## Variables de entorno necesarias
```
EXPO_PUBLIC_SUPABASE_URL=https://XXXXXXXX.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=tu_anon_key
EXPO_PUBLIC_ANTHROPIC_API_KEY=sk-ant-XXXXX
```

## Estructura recomendada para Expo
```
evitare-native/
├── app/
│   ├── (tabs)/
│   │   ├── index.tsx          # Inicio
│   │   ├── catalog.tsx        # Catálogo
│   │   ├── appointments.tsx   # Citas
│   │   ├── logbook.tsx        # Bitácora
│   │   └── chat.tsx           # Asistente IA
│   ├── _layout.tsx
│   └── login.tsx
├── src/
│   ├── lib/data.ts
│   └── components/
└── assets/
    ├── logo.png
    └── splash.png
```
