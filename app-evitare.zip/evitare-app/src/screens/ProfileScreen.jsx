import { useState } from 'react'

const DEMO_FAMILY = [
  { id: 1, name: 'Sofía González', relationship: 'hija', birth: '2023-08-10', blood: 'O+' },
]

export default function ProfileScreen({ user, onLogout }) {
  const [family, setFamily] = useState(DEMO_FAMILY)
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ name: '', relationship: 'hijo', birth: '', blood: '' })
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const age = (birth) => {
    const d = new Date(birth), now = new Date()
    const months = (now.getFullYear() - d.getFullYear()) * 12 + now.getMonth() - d.getMonth()
    return months < 24 ? `${months} meses` : `${Math.floor(months / 12)} años`
  }

  return (
    <div className="screen" style={{ background: 'var(--ev-surface)' }}>
      <div style={{ background: 'var(--ev-dark)', padding: '52px 20px 32px', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: -30, right: -30, width: 160, height: 160, borderRadius: '50%', background: 'rgba(29,158,117,0.1)' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, position: 'relative' }}>
          <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'linear-gradient(135deg, #1D9E75, #0B6B50)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, fontWeight: 700, color: '#fff' }}>
            {user.full_name?.[0]?.toUpperCase()}
          </div>
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 22, color: '#fff', marginBottom: 3 }}>{user.full_name}</h2>
            <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.55)' }}>{user.email}</p>
            <span style={{ fontSize: 11, background: 'rgba(29,158,117,0.3)', color: '#5DCAA5', borderRadius: 6, padding: '2px 8px', marginTop: 4, display: 'inline-block' }}>
              {user.role === 'admin' ? '👑 Administrador' : '🏥 Paciente'}
            </span>
          </div>
        </div>
      </div>

      <div style={{ padding: '20px' }}>
        {/* Datos personales */}
        <div className="card" style={{ marginBottom: 16 }}>
          <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--ev-text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 14 }}>Datos personales</p>
          {[
            ['Nombre completo', user.full_name, 'ti-user'],
            ['Correo', user.email || 'No registrado', 'ti-mail'],
            ['Teléfono', user.phone || 'No registrado', 'ti-phone'],
            ['Fecha de nacimiento', user.birth_date ? new Date(user.birth_date + 'T12:00:00').toLocaleDateString('es-MX', { day: 'numeric', month: 'long', year: 'numeric' }) : 'No registrado', 'ti-birthday-cake'],
          ].map(([l, v, icon]) => (
            <div key={l} style={{ display: 'flex', gap: 12, paddingBottom: 12, marginBottom: 12, borderBottom: '1px solid var(--ev-border)', alignItems: 'center' }}>
              <i className={`ti ${icon}`} style={{ fontSize: 18, color: 'var(--ev-green)', flexShrink: 0 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 12, color: 'var(--ev-text-muted)' }}>{l}</p>
                <p style={{ fontSize: 14, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v}</p>
              </div>
              <i className="ti ti-edit" style={{ fontSize: 16, color: 'var(--ev-border)', flexShrink: 0 }} />
            </div>
          ))}
        </div>

        {/* Familia */}
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--ev-text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Mi familia</p>
            <button onClick={() => setShowAdd(true)} style={{ background: 'none', border: 'none', color: 'var(--ev-green)', fontSize: 13, fontWeight: 500, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
              <i className="ti ti-plus" /> Agregar
            </button>
          </div>
          {family.map(f => (
            <div key={f.id} style={{ display: 'flex', gap: 12, alignItems: 'center', paddingBottom: 12, marginBottom: 12, borderBottom: '1px solid var(--ev-border)' }}>
              <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'var(--ev-green-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0 }}>
                {f.relationship.includes('hij') ? '👶' : f.relationship.includes('esposo') || f.relationship.includes('esposa') ? '💑' : '👤'}
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 14, fontWeight: 600 }}>{f.name}</p>
                <p style={{ fontSize: 12, color: 'var(--ev-text-muted)' }}>
                  {f.relationship} · {age(f.birth)} {f.blood && `· ${f.blood}`}
                </p>
              </div>
              <span className="badge badge-green" style={{ fontSize: 11 }}>Ver bitácora</span>
            </div>
          ))}
          {family.length === 0 && (
            <p style={{ fontSize: 13, color: 'var(--ev-text-muted)', textAlign: 'center', padding: '12px 0' }}>
              Agrega perfiles para cada miembro de tu familia
            </p>
          )}
        </div>

        {/* Clínica info */}
        <div className="card" style={{ background: 'var(--ev-dark)', marginBottom: 16 }}>
          <p style={{ fontSize: 13, fontWeight: 600, color: 'rgba(255,255,255,0.6)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>Contacto Evitare®</p>
          {[
            ['📞', '33 3813 2995 / 96'],
            ['📱', '+52 33 3849 0551 (WhatsApp)'],
            ['📧', 'auxiliar@evitare.org'],
            ['📍', 'Av. Aztecas 290, Fracc. Monraz'],
            ['⏰', 'Lun–Vie 9–17h · Sáb 9–15h'],
          ].map(([emoji, text]) => (
            <p key={text} style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)', marginBottom: 6 }}>{emoji} {text}</p>
          ))}
        </div>

        {/* Redes sociales */}
        <div className="card" style={{ marginBottom: 16 }}>
          <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--ev-text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>Síguenos</p>
          <div style={{ display: 'flex', gap: 10 }}>
            {[
              { name: 'Instagram', handle: '@evitare_medicalcenter', icon: 'ti-brand-instagram', color: '#E1306C', bg: '#FBF0F5' },
              { name: 'Facebook', handle: 'Evitaregdl', icon: 'ti-brand-facebook', color: '#1877F2', bg: '#E7F0FD' },
              { name: 'TikTok', handle: '@evitare_medicalcenter', icon: 'ti-brand-tiktok', color: '#000', bg: '#F5F5F5' },
            ].map(s => (
              <div key={s.name} style={{ flex: 1, background: s.bg, borderRadius: 10, padding: '10px 8px', textAlign: 'center', border: '1px solid var(--ev-border)' }}>
                <i className={`ti ${s.icon}`} style={{ fontSize: 22, color: s.color, display: 'block', marginBottom: 4 }} />
                <p style={{ fontSize: 10, color: 'var(--ev-text-muted)' }}>{s.name}</p>
              </div>
            ))}
          </div>
        </div>

        <button className="btn btn-ghost" style={{ width: '100%', padding: '13px', color: 'var(--ev-danger)', borderColor: '#FBBCB8' }} onClick={onLogout}>
          <i className="ti ti-logout" /> Cerrar sesión
        </button>
        <p style={{ textAlign: 'center', fontSize: 11, color: 'var(--ev-text-muted)', marginTop: 16, marginBottom: 8 }}>
          Evitare® Medical Center · Más de 20 años cuidando tu salud<br/>v1.0.0
        </p>
      </div>

      {/* Modal agregar familiar */}
      {showAdd && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(13,31,26,0.6)', zIndex: 200, display: 'flex', alignItems: 'flex-end' }} onClick={e => e.target === e.currentTarget && setShowAdd(false)}>
          <div style={{ background: 'var(--ev-white)', borderRadius: '24px 24px 0 0', padding: '24px 20px', width: '100%', animation: 'slideIn .3s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 20 }}>Agregar familiar</h3>
              <button onClick={() => setShowAdd(false)} style={{ background: 'var(--ev-border)', border: 'none', borderRadius: '50%', width: 32, height: 32, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="ti ti-x" style={{ fontSize: 16 }} />
              </button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {[['Nombre completo *', 'name', 'text', 'Nombre del familiar'], ['Fecha de nacimiento *', 'birth', 'date', ''], ['Tipo de sangre', 'blood', 'text', 'Ej: O+']].map(([l, k, t, p]) => (
                <div key={k}>
                  <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--ev-text-muted)', display: 'block', marginBottom: 6 }}>{l}</label>
                  <input className="input" type={t} placeholder={p} value={form[k]} onChange={e => set(k, e.target.value)} />
                </div>
              ))}
              <div>
                <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--ev-text-muted)', display: 'block', marginBottom: 6 }}>Parentesco *</label>
                <select className="input" value={form.relationship} onChange={e => set('relationship', e.target.value)}>
                  {['hijo','hija','esposo','esposa','madre','padre','abuelo','abuela','otro'].map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <button className="btn btn-primary" style={{ width: '100%', padding: '14px' }} onClick={() => {
                if (!form.name || !form.birth) return
                setFamily(p => [...p, { id: Date.now(), name: form.name, relationship: form.relationship, birth: form.birth, blood: form.blood }])
                setShowAdd(false)
                setForm({ name: '', relationship: 'hijo', birth: '', blood: '' })
              }}>
                <i className="ti ti-check" /> Agregar familiar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
