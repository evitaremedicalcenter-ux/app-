import { useState, useEffect } from 'react'
import { PACKAGES, VACCINES_CATALOG, DOMICILIO_INFO } from '../lib/data.js'

export default function HomeScreen({ user, onNavigate }) {
  const [time, setTime] = useState(new Date())
  useEffect(() => { const t = setInterval(() => setTime(new Date()), 60000); return () => clearInterval(t) }, [])
  const hour = time.getHours()
  const greeting = hour < 12 ? 'Buenos días' : hour < 18 ? 'Buenas tardes' : 'Buenas noches'
  const firstName = user.full_name?.split(' ')[0] || 'Paciente'
  const featured = VACCINES_CATALOG.filter(v => v.featured)

  return (
    <div className="screen" style={{ background: 'var(--ev-surface)' }}>
      {/* Header oscuro con logo */}
      <div style={{ background: 'var(--ev-dark)', padding: '52px 20px 28px', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: -60, right: -60, width: 260, height: 260, borderRadius: '50%', background: 'rgba(29,158,117,0.12)' }} />
        <div style={{ position: 'absolute', bottom: -20, right: 80, width: 120, height: 120, borderRadius: '50%', background: 'rgba(200,151,58,0.10)' }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, position: 'relative' }}>
          {/* Logo real */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <img src="/assets/logo-icon.jpg" alt="Evitare" style={{ width: 40, height: 40, borderRadius: 10, objectFit: 'cover' }} />
            <div>
              <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)', letterSpacing: '1px', textTransform: 'uppercase' }}>{greeting}, {firstName}</p>
              <p style={{ fontSize: 16, fontWeight: 600, color: '#fff', fontFamily: 'var(--font-display)' }}>Evitare® Medical Center</p>
            </div>
          </div>
          <button onClick={() => onNavigate('profile')} style={{ width: 42, height: 42, borderRadius: '50%', background: '#1D9E75', border: '2px solid rgba(255,255,255,0.2)', color: '#fff', fontSize: 17, fontWeight: 700, cursor: 'pointer' }}>
            {firstName[0]?.toUpperCase()}
          </button>
        </div>

        {/* Stats rápidas */}
        <div className="fade-up" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
          {[
            { icon: 'ti-vaccine', label: 'Vacunas', value: `${VACCINES_CATALOG.length}+`, color: '#1D9E75' },
            { icon: 'ti-package', label: 'Paquetes', value: `${PACKAGES.length}`, color: '#C8973A' },
            { icon: 'ti-home', label: 'Domicilio', value: '10–16h', color: '#185FA5' },
          ].map(s => (
            <div key={s.label} style={{ background: 'rgba(255,255,255,0.07)', borderRadius: 12, padding: '11px 8px', border: '1px solid rgba(255,255,255,0.08)', textAlign: 'center' }}>
              <i className={`ti ${s.icon}`} style={{ fontSize: 18, color: s.color, display: 'block', marginBottom: 3 }} />
              <p style={{ fontSize: 15, fontWeight: 700, color: '#fff', marginBottom: 1 }}>{s.value}</p>
              <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.45)' }}>{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '16px 20px 0' }}>
        {/* CTA Agendar */}
        <div onClick={() => onNavigate('appointments')} style={{ background: 'linear-gradient(135deg, #0B6B50 0%, #1D9E75 100%)', borderRadius: 16, padding: '16px 18px', marginBottom: 18, display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer', boxShadow: '0 4px 16px rgba(11,107,80,0.3)' }}>
          <div>
            <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.65)', marginBottom: 2 }}>¿Necesitas una vacuna?</p>
            <p style={{ fontSize: 17, fontWeight: 700, color: '#fff' }}>Agenda tu cita ahora</p>
            <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 3 }}>🏠 Clínica o a domicilio</p>
          </div>
          <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'rgba(255,255,255,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <i className="ti ti-arrow-right" style={{ fontSize: 22, color: '#fff' }} />
          </div>
        </div>

        {/* Accesos rápidos */}
        <p style={{ fontSize: 11, fontWeight: 600, color: 'var(--ev-text-muted)', letterSpacing: '0.8px', textTransform: 'uppercase', marginBottom: 10 }}>Accesos rápidos</p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 18 }}>
          {[
            { icon: 'ti-notebook',        label: 'Mi bitácora',   sub: 'Historial de vacunas',    screen: 'logbook',       color: '#0B6B50', bg: '#E6F5EE' },
            { icon: 'ti-calendar-plus',   label: 'Agendar cita',  sub: 'Clínica o domicilio',     screen: 'appointments',  color: '#C8973A', bg: '#FDF6E8' },
            { icon: 'ti-users',           label: 'Mi familia',    sub: 'Perfiles adicionales',    screen: 'profile',       color: '#185FA5', bg: '#E6F1FB' },
            { icon: 'ti-message-chatbot', label: 'Asistente IA',  sub: '"Prevenir es vivir"',     screen: 'chat',          color: '#993556', bg: '#FBF0F5' },
          ].map(a => (
            <div key={a.label} className="card" style={{ cursor: 'pointer', padding: '14px' }} onClick={() => onNavigate(a.screen)}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: a.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 9 }}>
                <i className={`ti ${a.icon}`} style={{ fontSize: 20, color: a.color }} />
              </div>
              <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--ev-text)', marginBottom: 2 }}>{a.label}</p>
              <p style={{ fontSize: 11, color: 'var(--ev-text-muted)' }}>{a.sub}</p>
            </div>
          ))}
        </div>

        {/* Paquetes populares */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <p style={{ fontSize: 11, fontWeight: 600, color: 'var(--ev-text-muted)', letterSpacing: '0.8px', textTransform: 'uppercase' }}>Paquetes populares</p>
          <button onClick={() => onNavigate('catalog')} style={{ background: 'none', border: 'none', color: 'var(--ev-green)', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Ver todo →</button>
        </div>
        <div style={{ display: 'flex', gap: 10, overflowX: 'auto', paddingBottom: 10, marginLeft: -20, paddingLeft: 20, paddingRight: 20, marginRight: -20, scrollbarWidth: 'none', marginBottom: 10 }}>
          {PACKAGES.map(p => (
            <div key={p.id} onClick={() => onNavigate('catalog')} style={{ minWidth: 210, background: 'var(--ev-white)', borderRadius: 14, border: '1px solid var(--ev-border)', padding: '14px', cursor: 'pointer', flexShrink: 0 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <span style={{ fontSize: 22 }}>{p.emoji}</span>
                <span style={{ fontSize: 10, background: p.color, color: p.accent, borderRadius: 6, padding: '2px 7px', fontWeight: 600 }}>{p.badge}</span>
              </div>
              <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--ev-text)', lineHeight: 1.3, marginBottom: 4 }}>{p.name}</p>
              <p style={{ fontSize: 19, fontWeight: 700, color: p.accent, marginBottom: 2 }}>${p.price.toLocaleString('es-MX')}</p>
              <p style={{ fontSize: 11, color: 'var(--ev-text-muted)' }}>{p.includes.length} servicios incluidos</p>
            </div>
          ))}
        </div>

        {/* Banner domicilio */}
        <div className="card" style={{ background: '#EAF3DE', border: '1px solid #C0DD97', marginBottom: 10 }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <img src="/assets/ruta.jpg" alt="Ruta" style={{ width: 64, height: 64, borderRadius: 10, objectFit: 'cover', flexShrink: 0 }} />
            <div>
              <p style={{ fontSize: 13, fontWeight: 700, color: '#27500A', marginBottom: 3 }}>🏠 #VacunasADomicilio</p>
              <p style={{ fontSize: 12, color: '#3B6D11', lineHeight: 1.4, marginBottom: 4 }}>Desde $3,000 → <strong>envío GRATIS</strong><br />Desde $1,500 → solo $100 extra</p>
              <p style={{ fontSize: 11, color: '#639922' }}>⏰ {DOMICILIO_INFO.horario}</p>
            </div>
          </div>
        </div>

        {/* Info clínica */}
        <div className="card" style={{ marginBottom: 8 }}>
          <div style={{ display: 'flex', gap: 12 }}>
            <img src="/assets/logo.avif" alt="Evitare" style={{ width: 44, height: 44, borderRadius: 10, objectFit: 'contain', background: '#E6F5EE', padding: 4, flexShrink: 0 }} onError={e => e.target.style.display='none'} />
            <div>
              <p style={{ fontSize: 13, fontWeight: 700, marginBottom: 4, color: 'var(--ev-text)' }}>Evitare® Medical Center</p>
              <p style={{ fontSize: 12, color: 'var(--ev-text-muted)', marginBottom: 1 }}>📍 Av. Aztecas 290, Fracc. Monraz</p>
              <p style={{ fontSize: 12, color: 'var(--ev-text-muted)', marginBottom: 1 }}>📞 33 3813 2995 / 96</p>
              <p style={{ fontSize: 12, color: 'var(--ev-text-muted)' }}>⏰ Lun–Vie 9–17h · Sáb 9–15h</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
