import { useState } from 'react'

const DEMO_RECORDS = [
  { id: 1, vaccine: 'SRP Triple Viral', dose: 1, date: '2024-03-15', clinic: 'Evitare Medical Center', lot: 'LOT2024A', next: '2024-09-15', evitare: true },
  { id: 2, vaccine: 'Influenza', dose: 1, date: '2024-01-20', clinic: 'Evitare Medical Center', lot: 'FLU2024B', next: '2025-01-20', evitare: true },
  { id: 3, vaccine: 'Hepatitis B', dose: 3, date: '2023-11-10', clinic: 'IMSS Clínica 46', lot: null, next: null, evitare: false },
  { id: 4, vaccine: 'BCG', dose: 1, date: '1990-05-15', clinic: 'Hospital Civil Guadalajara', lot: null, next: null, evitare: false },
]

export default function LogbookScreen({ user }) {
  const [records, setRecords] = useState(DEMO_RECORDS)
  const [showAdd, setShowAdd] = useState(false)
  const [tab, setTab] = useState('historial')
  const [form, setForm] = useState({ vaccine: '', dose: '1', date: '', clinic: '', lot: '', next: '' })

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const addRecord = () => {
    if (!form.vaccine || !form.date) return
    setRecords(p => [...p, { id: Date.now(), vaccine: form.vaccine, dose: parseInt(form.dose), date: form.date, clinic: form.clinic || 'Otro centro médico', lot: form.lot, next: form.next, evitare: false }])
    setForm({ vaccine: '', dose: '1', date: '', clinic: '', lot: '', next: '' })
    setShowAdd(false)
  }

  const upcoming = records.filter(r => r.next && new Date(r.next) > new Date()).sort((a, b) => new Date(a.next) - new Date(b.next))
  const daysUntil = (d) => Math.ceil((new Date(d) - new Date()) / 86400000)

  return (
    <div className="screen" style={{ background: 'var(--ev-surface)' }}>
      <div className="screen-header">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, color: 'var(--ev-dark)' }}>Mi Bitácora</h2>
          <button className="btn btn-primary" style={{ padding: '8px 14px', fontSize: 13 }} onClick={() => setShowAdd(true)}>
            <i className="ti ti-plus" style={{ fontSize: 16 }} /> Agregar
          </button>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {['historial', 'próximas'].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{ padding: '7px 16px', borderRadius: 20, border: 'none', background: tab === t ? 'var(--ev-green)' : 'var(--ev-border)', color: tab === t ? '#fff' : 'var(--ev-text-muted)', fontSize: 13, fontWeight: 500, cursor: 'pointer', textTransform: 'capitalize' }}>
              {t === 'historial' ? `📋 Historial (${records.length})` : `⏰ Próximas (${upcoming.length})`}
            </button>
          ))}
        </div>
      </div>

      {/* Resumen */}
      <div style={{ padding: '16px 20px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
          <div style={{ background: 'var(--ev-green-light)', borderRadius: 12, padding: '14px', border: '1px solid var(--ev-border)' }}>
            <p style={{ fontSize: 26, fontWeight: 700, color: 'var(--ev-green)', marginBottom: 2 }}>{records.length}</p>
            <p style={{ fontSize: 12, color: 'var(--ev-text-muted)' }}>Vacunas registradas</p>
          </div>
          <div style={{ background: upcoming.length > 0 ? 'var(--ev-warning-bg)' : 'var(--ev-green-light)', borderRadius: 12, padding: '14px', border: '1px solid var(--ev-border)' }}>
            <p style={{ fontSize: 26, fontWeight: 700, color: upcoming.length > 0 ? 'var(--ev-warning)' : 'var(--ev-green)', marginBottom: 2 }}>{upcoming.length}</p>
            <p style={{ fontSize: 12, color: 'var(--ev-text-muted)' }}>Dosis pendientes</p>
          </div>
        </div>
      </div>

      <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {tab === 'historial' && records.sort((a, b) => new Date(b.date) - new Date(a.date)).map(r => (
          <div key={r.id} className="card" style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
            <div style={{ width: 44, height: 44, borderRadius: '50%', background: r.evitare ? 'var(--ev-green-light)' : '#F0F0EE', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <i className="ti ti-vaccine" style={{ fontSize: 20, color: r.evitare ? 'var(--ev-green)' : 'var(--ev-text-muted)' }} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--ev-text)' }}>{r.vaccine}</p>
                <span className={`badge ${r.evitare ? 'badge-green' : 'badge-muted'}`} style={{ fontSize: 10, flexShrink: 0 }}>
                  {r.evitare ? '✓ Evitare' : 'Externo'}
                </span>
              </div>
              <p style={{ fontSize: 12, color: 'var(--ev-text-muted)', marginTop: 2 }}>
                Dosis {r.dose} · {new Date(r.date).toLocaleDateString('es-MX', { day: 'numeric', month: 'long', year: 'numeric' })}
              </p>
              <p style={{ fontSize: 12, color: 'var(--ev-text-muted)', marginTop: 1 }}>📍 {r.clinic}</p>
              {r.lot && <p style={{ fontSize: 11, color: 'var(--ev-text-muted)', marginTop: 1 }}>Lote: {r.lot}</p>}
              {r.next && (
                <p style={{ fontSize: 12, color: 'var(--ev-green)', marginTop: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
                  <i className="ti ti-calendar" style={{ fontSize: 12 }} />
                  Próxima dosis: {new Date(r.next).toLocaleDateString('es-MX', { day: 'numeric', month: 'long' })}
                </p>
              )}
            </div>
          </div>
        ))}

        {tab === 'próximas' && (
          upcoming.length === 0
            ? <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--ev-text-muted)' }}>
                <i className="ti ti-calendar-check" style={{ fontSize: 48, marginBottom: 12, display: 'block' }} />
                <p style={{ fontSize: 15, fontWeight: 500, marginBottom: 4 }}>¡Todo al día!</p>
                <p style={{ fontSize: 13 }}>No tienes dosis pendientes próximamente</p>
              </div>
            : upcoming.map(r => {
              const days = daysUntil(r.next)
              const urgent = days <= 7
              return (
                <div key={r.id} className="card" style={{ border: `1px solid ${urgent ? '#FBBCB8' : 'var(--ev-border)'}`, background: urgent ? 'var(--ev-danger-bg)' : 'var(--ev-white)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--ev-text)', marginBottom: 4 }}>{r.vaccine}</p>
                      <p style={{ fontSize: 12, color: 'var(--ev-text-muted)', marginBottom: 6 }}>Dosis {r.dose + 1} · {new Date(r.next).toLocaleDateString('es-MX', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                      <span className={`badge ${urgent ? 'badge-danger' : 'badge-green'}`} style={{ fontSize: 11 }}>
                        {urgent ? `⚠️ En ${days} días` : `📅 En ${days} días`}
                      </span>
                    </div>
                    <button className="btn btn-primary" style={{ padding: '8px 12px', fontSize: 12 }}>Agendar</button>
                  </div>
                </div>
              )
            })
        )}
      </div>

      {/* Modal agregar */}
      {showAdd && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(13,31,26,0.6)', zIndex: 200, display: 'flex', alignItems: 'flex-end' }} onClick={e => e.target === e.currentTarget && setShowAdd(false)}>
          <div style={{ background: 'var(--ev-white)', borderRadius: '24px 24px 0 0', padding: '24px 20px', width: '100%', maxHeight: '85dvh', overflowY: 'auto', animation: 'slideIn .3s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 20 }}>Agregar vacuna</h3>
              <button onClick={() => setShowAdd(false)} style={{ background: 'var(--ev-border)', border: 'none', borderRadius: '50%', width: 32, height: 32, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="ti ti-x" style={{ fontSize: 16 }} />
              </button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {[
                ['Nombre de la vacuna *', 'vaccine', 'text', 'Ej: Influenza'],
                ['Número de dosis *', 'dose', 'number', '1'],
                ['Fecha de aplicación *', 'date', 'date', ''],
                ['Centro médico', 'clinic', 'text', 'Ej: Evitare Medical Center'],
                ['Número de lote', 'lot', 'text', 'Opcional'],
                ['Fecha próxima dosis', 'next', 'date', ''],
              ].map(([label, key, type, ph]) => (
                <div key={key}>
                  <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--ev-text-muted)', display: 'block', marginBottom: 6 }}>{label}</label>
                  <input className="input" type={type} placeholder={ph} value={form[key]} onChange={e => set(key, e.target.value)} />
                </div>
              ))}
              <button className="btn btn-primary" style={{ width: '100%', padding: '14px', marginTop: 4 }} onClick={addRecord}>
                <i className="ti ti-check" /> Guardar vacuna
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
