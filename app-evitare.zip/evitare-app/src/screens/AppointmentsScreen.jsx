import { useState } from 'react'
import { VACCINES_CATALOG, TAMIZ_SERVICES } from '../lib/data.js'

const SLOTS = ['09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','14:00','15:00','15:30','16:00','16:30']

export default function AppointmentsScreen({ user }) {
  const [step, setStep] = useState(1) // 1=servicio, 2=tipo, 3=fecha, 4=confirm, 5=success
  const [appt, setAppt] = useState({ service: null, type: 'clinica', date: '', slot: '', address: '', email: user?.email || '', name: user?.full_name || '' })
  const [appointments, setAppointments] = useState([])
  const [tab, setTab] = useState('agendar')
  const [loading, setLoading] = useState(false)

  const set = (k, v) => setAppt(p => ({ ...p, [k]: v }))

  const allServices = [
    ...VACCINES_CATALOG.slice(0, 6).map(v => ({ ...v, type: 'vacuna' })),
    ...TAMIZ_SERVICES.map(t => ({ ...t, type: 'tamiz', emoji: '🧬', color: '#EAF3DE' })),
  ]

  const minDate = new Date(); minDate.setDate(minDate.getDate() + 1)
  const minDateStr = minDate.toISOString().split('T')[0]

  const confirm = async () => {
    setLoading(true)
    await new Promise(r => setTimeout(r, 1800))
    setAppointments(p => [...p, {
      id: Date.now(),
      service: appt.service?.name,
      type: appt.type,
      date: appt.date,
      slot: appt.slot,
      status: 'confirmada',
      address: appt.address,
    }])
    setLoading(false)
    setStep(5)
  }

  const reset = () => { setStep(1); setAppt({ service: null, type: 'clinica', date: '', slot: '', address: '', email: user?.email || '', name: user?.full_name || '' }) }

  if (tab === 'mis') return (
    <div className="screen" style={{ background: 'var(--ev-surface)' }}>
      <div className="screen-header">
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, color: 'var(--ev-dark)', marginBottom: 14 }}>Citas</h2>
        <div style={{ display: 'flex', gap: 6 }}>
          {['agendar','mis'].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{ padding: '7px 16px', borderRadius: 20, border: 'none', background: tab === t ? 'var(--ev-green)' : 'var(--ev-border)', color: tab === t ? '#fff' : 'var(--ev-text-muted)', fontSize: 13, fontWeight: 500, cursor: 'pointer' }}>
              {t === 'agendar' ? '📅 Agendar' : `🗓️ Mis citas (${appointments.length})`}
            </button>
          ))}
        </div>
      </div>
      <div style={{ padding: '16px 20px' }}>
        {appointments.length === 0
          ? <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--ev-text-muted)' }}>
              <i className="ti ti-calendar-off" style={{ fontSize: 48, display: 'block', marginBottom: 12 }} />
              <p style={{ fontSize: 15, fontWeight: 500, marginBottom: 4 }}>Sin citas agendadas</p>
              <p style={{ fontSize: 13, marginBottom: 20 }}>Agenda tu primera cita con Evitare®</p>
              <button className="btn btn-primary" style={{ padding: '12px 24px' }} onClick={() => setTab('agendar')}>Agendar ahora</button>
            </div>
          : appointments.map(a => (
            <div key={a.id} className="card" style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                <p style={{ fontSize: 15, fontWeight: 600 }}>{a.service}</p>
                <span className="badge badge-green">✓ Confirmada</span>
              </div>
              <p style={{ fontSize: 13, color: 'var(--ev-text-muted)', marginBottom: 4 }}>
                📅 {new Date(a.date).toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' })} · {a.slot}
              </p>
              <p style={{ fontSize: 13, color: 'var(--ev-text-muted)' }}>
                {a.type === 'clinica' ? '🏥 Av. Aztecas 290, Fracc. Monraz' : `🏠 ${a.address}`}
              </p>
            </div>
          ))
        }
      </div>
    </div>
  )

  return (
    <div className="screen" style={{ background: 'var(--ev-surface)' }}>
      <div className="screen-header">
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, color: 'var(--ev-dark)', marginBottom: 14 }}>Citas</h2>
        <div style={{ display: 'flex', gap: 6 }}>
          {['agendar','mis'].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{ padding: '7px 16px', borderRadius: 20, border: 'none', background: tab === t ? 'var(--ev-green)' : 'var(--ev-border)', color: tab === t ? '#fff' : 'var(--ev-text-muted)', fontSize: 13, fontWeight: 500, cursor: 'pointer' }}>
              {t === 'agendar' ? '📅 Agendar' : `🗓️ Mis citas (${appointments.length})`}
            </button>
          ))}
        </div>
      </div>

      {/* Progreso */}
      {step < 5 && (
        <div style={{ padding: '12px 20px', display: 'flex', gap: 6 }}>
          {[1,2,3,4].map(s => (
            <div key={s} style={{ flex: 1, height: 4, borderRadius: 2, background: s <= step ? 'var(--ev-green)' : 'var(--ev-border)', transition: 'background .3s' }} />
          ))}
        </div>
      )}

      <div style={{ padding: '0 20px' }}>
        {/* PASO 1 - Servicio */}
        {step === 1 && (
          <div className="fade-up">
            <p style={{ fontSize: 16, fontWeight: 600, color: 'var(--ev-text)', marginBottom: 4, marginTop: 8 }}>¿Qué vacuna o servicio necesitas?</p>
            <p style={{ fontSize: 13, color: 'var(--ev-text-muted)', marginBottom: 16 }}>Selecciona una opción del catálogo</p>
            {allServices.map(s => (
              <div key={s.id} onClick={() => { set('service', s); setStep(2) }} style={{ display: 'flex', gap: 12, alignItems: 'center', padding: '14px', background: 'var(--ev-white)', borderRadius: 12, border: `2px solid ${appt.service?.id === s.id ? 'var(--ev-green)' : 'var(--ev-border)'}`, marginBottom: 8, cursor: 'pointer' }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: s.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>
                  {s.emoji}
                </div>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 14, fontWeight: 600 }}>{s.name}</p>
                  <p style={{ fontSize: 12, color: 'var(--ev-text-muted)' }}>{s.age || s.desc?.slice(0, 50) + '...'}</p>
                </div>
                <i className="ti ti-chevron-right" style={{ color: 'var(--ev-border)', fontSize: 18 }} />
              </div>
            ))}
          </div>
        )}

        {/* PASO 2 - Tipo de atención */}
        {step === 2 && (
          <div className="fade-up">
            <button onClick={() => setStep(1)} style={{ background: 'none', border: 'none', color: 'var(--ev-text-muted)', fontSize: 13, display: 'flex', alignItems: 'center', gap: 4, cursor: 'pointer', marginBottom: 16, marginTop: 8 }}>
              <i className="ti ti-arrow-left" /> Regresar
            </button>
            <p style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>Tipo de atención</p>
            <p style={{ fontSize: 13, color: 'var(--ev-text-muted)', marginBottom: 16 }}>Seleccionaste: <strong>{appt.service?.name}</strong></p>
            {[
              { val: 'clinica', icon: 'ti-building-hospital', title: 'En clínica', sub: 'Av. Aztecas 290, Fracc. Monraz', color: 'var(--ev-green-light)', accent: 'var(--ev-green)' },
              { val: 'domicilio', icon: 'ti-home', title: 'A domicilio', sub: 'Personal llega con equipo desinfectado', color: '#FDF6E8', accent: '#C8973A', disabled: !appt.service?.home },
            ].map(o => (
              <div key={o.val} onClick={() => !o.disabled && set('type', o.val)} style={{ padding: '18px', background: 'var(--ev-white)', borderRadius: 14, border: `2px solid ${appt.type === o.val ? o.accent : 'var(--ev-border)'}`, marginBottom: 10, cursor: o.disabled ? 'not-allowed' : 'pointer', opacity: o.disabled ? 0.5 : 1, display: 'flex', alignItems: 'center', gap: 14 }}>
                <div style={{ width: 48, height: 48, borderRadius: 12, background: o.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <i className={`ti ${o.icon}`} style={{ fontSize: 24, color: o.accent }} />
                </div>
                <div>
                  <p style={{ fontSize: 15, fontWeight: 600 }}>{o.title}</p>
                  <p style={{ fontSize: 13, color: 'var(--ev-text-muted)' }}>{o.disabled ? 'No disponible para esta vacuna' : o.sub}</p>
                </div>
              </div>
            ))}
            {appt.type === 'domicilio' && (
              <div style={{ marginTop: 12, marginBottom: 12 }}>
                <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--ev-text-muted)', display: 'block', marginBottom: 6 }}>Dirección completa</label>
                <input className="input" placeholder="Calle, número, colonia, Guadalajara" value={appt.address} onChange={e => set('address', e.target.value)} />
              </div>
            )}
            <button className="btn btn-primary" style={{ width: '100%', padding: '14px', marginTop: 8 }} onClick={() => setStep(3)}>
              Continuar →
            </button>
          </div>
        )}

        {/* PASO 3 - Fecha y hora */}
        {step === 3 && (
          <div className="fade-up">
            <button onClick={() => setStep(2)} style={{ background: 'none', border: 'none', color: 'var(--ev-text-muted)', fontSize: 13, display: 'flex', alignItems: 'center', gap: 4, cursor: 'pointer', marginBottom: 16, marginTop: 8 }}>
              <i className="ti ti-arrow-left" /> Regresar
            </button>
            <p style={{ fontSize: 16, fontWeight: 600, marginBottom: 16 }}>Selecciona fecha y hora</p>
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--ev-text-muted)', display: 'block', marginBottom: 6 }}>Fecha (Lun–Vie 9–17h · Sáb 9–15h)</label>
              <input className="input" type="date" min={minDateStr} value={appt.date} onChange={e => set('date', e.target.value)} />
            </div>
            {appt.date && (
              <>
                <p style={{ fontSize: 13, fontWeight: 500, color: 'var(--ev-text-muted)', marginBottom: 10 }}>Horarios disponibles</p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 16 }}>
                  {SLOTS.map(s => (
                    <button key={s} onClick={() => set('slot', s)} style={{ padding: '10px', borderRadius: 10, border: `2px solid ${appt.slot === s ? 'var(--ev-green)' : 'var(--ev-border)'}`, background: appt.slot === s ? 'var(--ev-green-light)' : 'var(--ev-white)', color: appt.slot === s ? 'var(--ev-green)' : 'var(--ev-text)', fontSize: 14, fontWeight: appt.slot === s ? 600 : 400, cursor: 'pointer' }}>
                      {s}
                    </button>
                  ))}
                </div>
              </>
            )}
            <button className="btn btn-primary" style={{ width: '100%', padding: '14px' }} disabled={!appt.date || !appt.slot} onClick={() => setStep(4)}>
              Continuar →
            </button>
          </div>
        )}

        {/* PASO 4 - Confirmación */}
        {step === 4 && (
          <div className="fade-up">
            <button onClick={() => setStep(3)} style={{ background: 'none', border: 'none', color: 'var(--ev-text-muted)', fontSize: 13, display: 'flex', alignItems: 'center', gap: 4, cursor: 'pointer', marginBottom: 16, marginTop: 8 }}>
              <i className="ti ti-arrow-left" /> Regresar
            </button>
            <p style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>Confirmar cita</p>
            <p style={{ fontSize: 13, color: 'var(--ev-text-muted)', marginBottom: 16 }}>Revisa los detalles antes de confirmar</p>
            <div className="card" style={{ marginBottom: 16 }}>
              {[
                ['Servicio', appt.service?.name, 'ti-vaccine'],
                ['Tipo', appt.type === 'clinica' ? 'En clínica' : 'A domicilio', 'ti-building-hospital'],
                ['Fecha', new Date(appt.date + 'T12:00:00').toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }), 'ti-calendar'],
                ['Hora', appt.slot, 'ti-clock'],
                ['Lugar', appt.type === 'clinica' ? 'Av. Aztecas 290, Fracc. Monraz' : appt.address, 'ti-map-pin'],
              ].map(([l, v, icon]) => (
                <div key={l} style={{ display: 'flex', gap: 12, paddingBottom: 12, marginBottom: 12, borderBottom: '1px solid var(--ev-border)', alignItems: 'flex-start' }}>
                  <i className={`ti ${icon}`} style={{ fontSize: 18, color: 'var(--ev-green)', flexShrink: 0, marginTop: 1 }} />
                  <div>
                    <p style={{ fontSize: 12, color: 'var(--ev-text-muted)' }}>{l}</p>
                    <p style={{ fontSize: 14, fontWeight: 500 }}>{v}</p>
                  </div>
                </div>
              ))}
              <div style={{ marginBottom: 0 }}>
                <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--ev-text-muted)', display: 'block', marginBottom: 6 }}>Correo para invitación de Google Calendar</label>
                <input className="input" type="email" value={appt.email} onChange={e => set('email', e.target.value)} placeholder="tu@correo.com" />
              </div>
            </div>
            <button className="btn btn-primary" style={{ width: '100%', padding: '15px', fontSize: 16 }} onClick={confirm} disabled={loading}>
              {loading ? <><span className="spinner" style={{ borderTopColor: '#fff', width: 18, height: 18 }} /> Agendando...</> : '✅ Confirmar cita'}
            </button>
          </div>
        )}

        {/* ÉXITO */}
        {step === 5 && (
          <div className="fade-up" style={{ textAlign: 'center', padding: '40px 20px' }}>
            <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'var(--ev-green-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px', border: '2px solid var(--ev-green)' }}>
              <i className="ti ti-circle-check" style={{ fontSize: 44, color: 'var(--ev-green)' }} />
            </div>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 26, color: 'var(--ev-dark)', marginBottom: 8 }}>¡Cita confirmada!</h3>
            <p style={{ fontSize: 14, color: 'var(--ev-text-muted)', marginBottom: 4 }}>
              {new Date(appt.date + 'T12:00:00').toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' })} · {appt.slot}
            </p>
            <p style={{ fontSize: 13, color: 'var(--ev-text-muted)', marginBottom: 28 }}>
              Recibirás un recordatorio 24 horas antes en {appt.email}
            </p>
            <div className="card" style={{ textAlign: 'left', marginBottom: 20 }}>
              <p style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>📋 Preparación</p>
              <ul style={{ fontSize: 13, color: 'var(--ev-text-muted)', paddingLeft: 16, lineHeight: 1.8 }}>
                <li>Lleva tu carnet de vacunación anterior</li>
                <li>Informa si tomas algún medicamento</li>
                <li>Viste ropa de manga corta o suelta</li>
                {appt.type === 'domicilio' && <li>El personal llegará puntualmente a tu domicilio</li>}
              </ul>
            </div>
            <button className="btn btn-outline" style={{ width: '100%', padding: '13px', marginBottom: 10 }} onClick={() => setTab('mis')}>
              Ver mis citas
            </button>
            <button className="btn btn-ghost" style={{ width: '100%', padding: '13px' }} onClick={reset}>
              Agendar otra cita
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
