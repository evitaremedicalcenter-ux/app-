import { useState } from 'react'
import { VACCINES_CATALOG, TAMIZ_SERVICES, PACKAGES, calcDomicilio, DOMICILIO_INFO } from '../lib/data.js'

export default function CatalogScreen({ onNavigate }) {
  const [tab, setTab]       = useState('paquetes')
  const [filter, setFilter] = useState('todos')
  const [selected, setSelected] = useState(null)
  const [search, setSearch] = useState('')

  const cats = ['todos','bebe','adulto']
  const filtered = VACCINES_CATALOG.filter(v => {
    const matchCat = filter === 'todos' || v.category === filter
    const matchSearch = !search || v.name.toLowerCase().includes(search.toLowerCase()) || v.disease.toLowerCase().includes(search.toLowerCase())
    return matchCat && matchSearch
  })

  const fmt = (n) => `$${Number(n).toLocaleString('es-MX')}`

  // Detalle vacuna
  if (selected && selected._type === 'vaccine') {
    const v = selected
    const domicilio = calcDomicilio(v.price)
    return (
      <div className="screen">
        <div style={{ background: v.color, padding: '52px 20px 24px' }}>
          <button onClick={() => setSelected(null)} style={{ background: 'rgba(255,255,255,0.8)', border: 'none', borderRadius: 10, padding: '7px 13px', fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, marginBottom: 16 }}>
            <i className="ti ti-arrow-left" /> Regresar
          </button>
          <div style={{ fontSize: 44, marginBottom: 10 }}>{v.emoji}</div>
          {v.featured && <span className="badge badge-gold" style={{ marginBottom: 8, display: 'inline-flex' }}>⭐ Vacuna del mes</span>}
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 26, color: 'var(--ev-dark)', lineHeight: 1.2, marginBottom: 2 }}>{v.name}</h2>
          {v.lab && <p style={{ fontSize: 12, color: 'var(--ev-text-muted)' }}>Laboratorio: {v.lab}</p>}
        </div>
        <div style={{ padding: '16px 20px' }}>
          {/* Precio destacado */}
          <div className="card" style={{ background: 'var(--ev-dark)', marginBottom: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginBottom: 2 }}>Precio 2026</p>
              <p style={{ fontSize: 30, fontWeight: 700, color: '#fff', fontFamily: 'var(--font-display)' }}>{fmt(v.price)}</p>
            </div>
            <div style={{ textAlign: 'right' }}>
              <p style={{ fontSize: 11, color: domicilio.costo === 0 ? '#22C55E' : 'rgba(255,255,255,0.5)', fontWeight: domicilio.costo === 0 ? 600 : 400 }}>{domicilio.label}</p>
            </div>
          </div>
          <div className="card" style={{ marginBottom: 14 }}>
            <p style={{ fontSize: 11, fontWeight: 600, color: 'var(--ev-text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>Información</p>
            {[
              v.disease   && ['Protege contra', v.disease, 'ti-shield-check'],
              v.age       && ['Edad recomendada', v.age, 'ti-birthday-cake'],
              v.doses     && ['Número de dosis', `${v.doses} ${v.doses===1?'dosis':'dosis'}`, 'ti-vaccine'],
              v.interval  && ['Intervalo', v.interval, 'ti-clock'],
              ['Servicio a domicilio', v.home ? '✓ Disponible' : 'Solo en clínica', 'ti-home'],
            ].filter(Boolean).map(([l,val,icon]) => (
              <div key={l} style={{ display:'flex', justifyContent:'space-between', paddingBottom:10, marginBottom:10, borderBottom:'1px solid var(--ev-border)' }}>
                <span style={{ fontSize:13, color:'var(--ev-text-muted)', display:'flex', alignItems:'center', gap:5 }}>
                  <i className={`ti ${icon}`} style={{ fontSize:15 }}/>{l}
                </span>
                <span style={{ fontSize:13, fontWeight:500, color:'var(--ev-text)', maxWidth:'55%', textAlign:'right' }}>{val}</span>
              </div>
            ))}
            <p style={{ fontSize:13, color:'var(--ev-text-muted)', lineHeight:1.6 }}>{v.desc}</p>
          </div>
          <button className="btn btn-primary" style={{ width:'100%', padding:'14px' }} onClick={() => onNavigate('appointments')}>
            <i className="ti ti-calendar-plus"/> Agendar esta vacuna
          </button>
        </div>
      </div>
    )
  }

  // Detalle paquete
  if (selected && selected._type === 'package') {
    const p = selected
    const domicilio = calcDomicilio(p.price)
    return (
      <div className="screen">
        <div style={{ background: p.color, padding: '52px 20px 24px' }}>
          <button onClick={() => setSelected(null)} style={{ background: 'rgba(255,255,255,0.8)', border: 'none', borderRadius: 10, padding: '7px 13px', fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, marginBottom: 16 }}>
            <i className="ti ti-arrow-left" /> Regresar
          </button>
          <div style={{ fontSize: 44, marginBottom: 10 }}>{p.emoji}</div>
          <span style={{ fontSize: 11, background: p.color, color: p.accent, borderRadius: 6, padding: '3px 10px', fontWeight: 700, marginBottom: 10, display: 'inline-block' }}>{p.badge}</span>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 26, color: 'var(--ev-dark)', lineHeight: 1.2 }}>{p.name}</h2>
        </div>
        <div style={{ padding: '16px 20px' }}>
          <div className="card" style={{ background: 'var(--ev-dark)', marginBottom: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginBottom: 2 }}>Precio del paquete</p>
                <p style={{ fontSize: 32, fontWeight: 700, color: '#fff', fontFamily: 'var(--font-display)' }}>{fmt(p.price)}</p>
              </div>
              <div style={{ textAlign: 'right' }}>
                <p style={{ fontSize: 11, color: domicilio.costo === 0 ? '#22C55E' : '#C8973A', fontWeight: 600 }}>{domicilio.label}</p>
              </div>
            </div>
          </div>
          <div className="card" style={{ marginBottom: 14 }}>
            <p style={{ fontSize: 11, fontWeight: 600, color: 'var(--ev-text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>Incluye</p>
            {p.includes.map((item, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, paddingBottom: 10, marginBottom: 10, borderBottom: i < p.includes.length-1 ? '1px solid var(--ev-border)' : 'none' }}>
                <div style={{ width: 28, height: 28, borderRadius: '50%', background: p.color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <i className="ti ti-check" style={{ fontSize: 14, color: p.accent }} />
                </div>
                <p style={{ fontSize: 14, color: 'var(--ev-text)' }}>{item}</p>
              </div>
            ))}
          </div>
          {p.variant && (
            <div className="card" style={{ background: 'var(--ev-warning-bg)', border: '1px solid #F9D985', marginBottom: 14 }}>
              <p style={{ fontSize: 12, fontWeight: 600, color: '#92400E', marginBottom: 6 }}>🔄 Opción alternativa: {p.variant.label}</p>
              <p style={{ fontSize: 20, fontWeight: 700, color: '#854F0B', marginBottom: 4 }}>{fmt(p.variant.price)}</p>
              {p.variant.includes.map((item,i) => <p key={i} style={{ fontSize: 12, color: '#92400E' }}>• {item}</p>)}
            </div>
          )}
          <p style={{ fontSize: 13, color: 'var(--ev-text-muted)', lineHeight: 1.5, marginBottom: 14 }}>{p.desc}</p>
          <button className="btn btn-primary" style={{ width:'100%', padding:'14px' }} onClick={() => onNavigate('appointments')}>
            <i className="ti ti-calendar-plus"/> Agendar este paquete
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="screen">
      <div className="screen-header">
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, color: 'var(--ev-dark)', marginBottom: 12 }}>Catálogo 2026</h2>
        {/* Tabs */}
        <div style={{ display: 'flex', gap: 6, marginBottom: 10, overflowX: 'auto', scrollbarWidth: 'none' }}>
          {[['paquetes','📦 Paquetes'],['vacunas','💉 Vacunas'],['tamiz','🧬 Tamiz'],['domicilio','🏠 Domicilio']].map(([t,label]) => (
            <button key={t} onClick={() => setTab(t)} style={{ padding:'6px 14px', borderRadius:20, border:'none', background: tab===t?'var(--ev-green)':'var(--ev-border)', color: tab===t?'#fff':'var(--ev-text-muted)', fontSize:13, fontWeight:500, cursor:'pointer', whiteSpace:'nowrap' }}>
              {label}
            </button>
          ))}
        </div>
        {tab === 'vacunas' && (
          <>
            <input className="input" placeholder="🔍 Buscar vacuna o enfermedad..." value={search} onChange={e => setSearch(e.target.value)} style={{ marginBottom: 8, fontSize: 13 }} />
            <div style={{ display: 'flex', gap: 5, overflowX: 'auto', scrollbarWidth: 'none' }}>
              {cats.map(c => (
                <button key={c} onClick={() => setFilter(c)} style={{ padding:'4px 12px', borderRadius:16, border:`1px solid ${filter===c?'var(--ev-green)':'var(--ev-border)'}`, background: filter===c?'var(--ev-green-light)':'transparent', color: filter===c?'var(--ev-green)':'var(--ev-text-muted)', fontSize:12, fontWeight:500, cursor:'pointer', whiteSpace:'nowrap' }}>
                  {c==='todos'?'Todos':c==='bebe'?'👶 Bebés':'👤 Adultos'}
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      <div style={{ padding: '12px 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {/* PAQUETES */}
        {tab === 'paquetes' && PACKAGES.map(p => (
          <div key={p.id} className="card" style={{ cursor:'pointer', position:'relative', overflow:'hidden' }} onClick={() => setSelected({...p, _type:'package'})}>
            <div style={{ position:'absolute', top:0, left:0, right:0, height:3, background:`linear-gradient(90deg, ${p.accent}, ${p.color})` }} />
            <div style={{ paddingTop: 6, display:'flex', gap:12, alignItems:'flex-start' }}>
              <div style={{ width:48, height:48, borderRadius:12, background:p.color, display:'flex', alignItems:'center', justifyContent:'center', fontSize:24, flexShrink:0 }}>{p.emoji}</div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:6, marginBottom:4 }}>
                  <p style={{ fontSize:14, fontWeight:700, color:'var(--ev-text)', lineHeight:1.3 }}>{p.name}</p>
                  <span style={{ fontSize:10, background:p.color, color:p.accent, borderRadius:5, padding:'2px 7px', fontWeight:600, flexShrink:0 }}>{p.badge}</span>
                </div>
                <div style={{ display:'flex', gap:4, flexWrap:'wrap', marginBottom:6 }}>
                  {p.includes.map((item,i) => <span key={i} style={{ fontSize:10, background:'#F3F4F6', color:'var(--ev-text-muted)', borderRadius:4, padding:'2px 6px' }}>{item}</span>)}
                </div>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                  <p style={{ fontSize:20, fontWeight:700, color:p.accent }}>${p.price.toLocaleString('es-MX')}</p>
                  {p.price >= 3000 && <span style={{ fontSize:10, background:'#DCFCE7', color:'#166534', borderRadius:5, padding:'2px 7px', fontWeight:600 }}>🚚 Envío GRATIS</span>}
                </div>
              </div>
            </div>
            {p.variant && <p style={{ fontSize:11, color:'var(--ev-text-muted)', marginTop:8, paddingTop:8, borderTop:'1px solid var(--ev-border)' }}>🔄 También disponible: {p.variant.label} — ${p.variant.price.toLocaleString('es-MX')}</p>}
          </div>
        ))}

        {/* VACUNAS */}
        {tab === 'vacunas' && filtered.map(v => (
          <div key={v.id} className="card" style={{ cursor:'pointer', display:'flex', gap:12, alignItems:'flex-start' }} onClick={() => setSelected({...v, _type:'vaccine'})}>
            <div style={{ width:46, height:46, borderRadius:12, background:v.color, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22, flexShrink:0 }}>{v.emoji}</div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:6, marginBottom:3 }}>
                <p style={{ fontSize:14, fontWeight:600, color:'var(--ev-text)', lineHeight:1.3 }}>{v.name}</p>
                {v.featured && <span className="badge badge-gold" style={{ fontSize:10, flexShrink:0 }}>⭐</span>}
              </div>
              <p style={{ fontSize:11, color:'var(--ev-text-muted)', marginBottom:6 }}>{v.disease}</p>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <p style={{ fontSize:17, fontWeight:700, color:'var(--ev-green)' }}>${v.price.toLocaleString('es-MX')}</p>
                <div style={{ display:'flex', gap:4 }}>
                  {v.home && <span style={{ fontSize:10, background:'#E6F5EE', color:'var(--ev-green)', borderRadius:4, padding:'2px 6px', fontWeight:500 }}>🏠</span>}
                  <span style={{ fontSize:10, background:'#F0F0EE', color:'var(--ev-text-muted)', borderRadius:4, padding:'2px 6px' }}>{v.doses} dosis</span>
                </div>
              </div>
            </div>
            <i className="ti ti-chevron-right" style={{ color:'var(--ev-border)', fontSize:16, flexShrink:0, marginTop:4 }} />
          </div>
        ))}
        {tab === 'vacunas' && filtered.length === 0 && (
          <div style={{ textAlign:'center', padding:'40px 20px', color:'var(--ev-text-muted)' }}>
            <i className="ti ti-search" style={{ fontSize:40, marginBottom:10, display:'block' }} />
            <p style={{ fontSize:14 }}>No se encontraron vacunas para "{search}"</p>
          </div>
        )}

        {/* TAMIZ */}
        {tab === 'tamiz' && TAMIZ_SERVICES.map(t => (
          <div key={t.id} className="card" style={{ display:'flex', gap:12 }}>
            <div style={{ width:48, height:48, borderRadius:12, background:'#EAF3DE', display:'flex', alignItems:'center', justifyContent:'center', fontSize:24, flexShrink:0 }}>{t.emoji}</div>
            <div style={{ flex:1 }}>
              <p style={{ fontSize:14, fontWeight:600, color:'var(--ev-text)', marginBottom:4 }}>{t.name}</p>
              <p style={{ fontSize:12, color:'var(--ev-text-muted)', lineHeight:1.5, marginBottom:8 }}>{t.desc}</p>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <p style={{ fontSize:20, fontWeight:700, color:'var(--ev-green)' }}>${t.price.toLocaleString('es-MX')}</p>
                <button className="btn btn-primary" style={{ padding:'7px 14px', fontSize:12 }} onClick={() => onNavigate('appointments')}>Agendar</button>
              </div>
            </div>
          </div>
        ))}

        {/* DOMICILIO */}
        {tab === 'domicilio' && (
          <>
            <img src="/assets/ruta.jpg" alt="Servicio a domicilio Evitare" style={{ width:'100%', borderRadius:14, height:180, objectFit:'cover' }} />
            <div className="card" style={{ background:'linear-gradient(135deg, #0B6B50, #1D9E75)', border:'none' }}>
              <p style={{ fontSize:16, fontWeight:700, color:'#fff', marginBottom:4 }}>🏠 #VacunasADomicilio</p>
              <p style={{ fontSize:13, color:'rgba(255,255,255,0.8)', lineHeight:1.5 }}>Nuestro personal llega con gel antibacterial y equipo completamente desinfectado.</p>
            </div>
            {[
              { label:'Servicio de $1,500 a $2,999', costo:'$100 adicional', color:'#FDF6E8', text:'#92400E', icon:'🚗' },
              { label:'Servicio de $3,000 en adelante', costo:'¡GRATIS! 🎉', color:'#DCFCE7', text:'#166534', icon:'🎁' },
            ].map(r => (
              <div key={r.label} className="card" style={{ background:r.color, border:'none', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <div>
                  <p style={{ fontSize:13, fontWeight:600, color:r.text }}>{r.icon} {r.label}</p>
                  <p style={{ fontSize:11, color:r.text, opacity:.7 }}>Dentro del Anillo Periférico del AMG</p>
                </div>
                <p style={{ fontSize:18, fontWeight:800, color:r.text }}>{r.costo}</p>
              </div>
            ))}
            <div className="card">
              <p style={{ fontSize:13, fontWeight:600, color:'var(--ev-text)', marginBottom:10 }}>📋 Información importante</p>
              {[
                `⏰ Horario: ${DOMICILIO_INFO.horario}`,
                '📍 Solo dentro del Anillo Periférico del AMG',
                '📲 Avisamos 30 minutos antes de llegar',
                '🌍 Fuera del Anillo Periférico: costo por km extra',
                '🧴 Personal con gel y equipo desinfectado',
              ].map(item => <p key={item} style={{ fontSize:12, color:'var(--ev-text-muted)', marginBottom:6, lineHeight:1.4 }}>{item}</p>)}
            </div>
            <div className="card" style={{ background:'var(--ev-dark)', border:'none' }}>
              <p style={{ fontSize:13, fontWeight:600, color:'#fff', marginBottom:10 }}>¿Cómo solicitar?</p>
              <a href={`https://wa.me/${DOMICILIO_INFO.whatsapp.replace(/\D/g,'')}`} style={{ display:'flex', alignItems:'center', gap:10, background:'#25D366', borderRadius:10, padding:'12px 14px', textDecoration:'none', marginBottom:8 }}>
                <i className="ti ti-brand-whatsapp" style={{ fontSize:22, color:'#fff' }} />
                <div>
                  <p style={{ fontSize:13, fontWeight:600, color:'#fff' }}>WhatsApp</p>
                  <p style={{ fontSize:12, color:'rgba(255,255,255,0.8)' }}>{DOMICILIO_INFO.whatsapp}</p>
                </div>
              </a>
              <div style={{ display:'flex', alignItems:'center', gap:10, background:'rgba(255,255,255,0.08)', borderRadius:10, padding:'12px 14px' }}>
                <i className="ti ti-phone" style={{ fontSize:22, color:'#1D9E75' }} />
                <div>
                  <p style={{ fontSize:13, fontWeight:600, color:'#fff' }}>Teléfono</p>
                  <p style={{ fontSize:12, color:'rgba(255,255,255,0.7)' }}>{DOMICILIO_INFO.phone}</p>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
