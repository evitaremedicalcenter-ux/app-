import { useState } from 'react'
import { supabase } from '../lib/data.js'

export default function LoginScreen({ onLogin }) {
  const [mode, setMode] = useState('welcome')
  const [form, setForm] = useState({ email:'', password:'', name:'', phone:'' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const set = (k,v) => setForm(p => ({...p,[k]:v}))

  const handleDemo = () => onLogin({ id:'demo', full_name:'Usuario Demo', email:'demo@evitare.org', role:'patient', phone:'+52 33 1234 5678', birth_date:'1990-05-15' })

  const handleAuth = async () => {
    if (!supabase) return handleDemo()
    setLoading(true); setError('')
    try {
      if (mode === 'login') {
        const { data, error:e } = await supabase.auth.signInWithPassword({ email:form.email, password:form.password })
        if (e) throw e
        const { data:profile } = await supabase.from('profiles').select('*').eq('auth_user_id', data.user.id).single()
        onLogin(profile || { id:data.user.id, full_name:form.email.split('@')[0], email:form.email, role:'patient' })
      } else {
        const { data, error:e } = await supabase.auth.signUp({ email:form.email, password:form.password })
        if (e) throw e
        await supabase.from('profiles').insert({ auth_user_id:data.user.id, full_name:form.name, email:form.email, phone:form.phone, role:'patient' })
        onLogin({ id:data.user.id, full_name:form.name, email:form.email, role:'patient' })
      }
    } catch(e) { setError(e.message) }
    setLoading(false)
  }

  if (mode === 'welcome') return (
    <div style={{ minHeight:'100dvh', display:'flex', flexDirection:'column', background:'var(--ev-dark)', position:'relative', overflow:'hidden' }}>
      <div style={{ position:'absolute', top:-80, right:-80, width:320, height:320, borderRadius:'50%', background:'rgba(29,158,117,0.15)' }} />
      <div style={{ position:'absolute', bottom:100, left:-60, width:240, height:240, borderRadius:'50%', background:'rgba(200,151,58,0.10)' }} />

      <div style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'40px 32px' }}>
        {/* Logo real */}
        <div className="fade-up" style={{ position:'relative', marginBottom:28 }}>
          <div style={{ width:88, height:88, borderRadius:22, background:'linear-gradient(135deg, #1D9E75, #0B6B50)', display:'flex', alignItems:'center', justifyContent:'center', boxShadow:'0 8px 32px rgba(29,158,117,0.5)' }}>
            <img src="/assets/logo-icon.jpg" alt="Evitare" style={{ width:64, height:64, borderRadius:12, objectFit:'cover' }} onError={e => { e.target.style.display='none'; e.target.nextSibling.style.display='flex' }} />
            <div style={{ display:'none', alignItems:'center', justifyContent:'center', width:'100%', height:'100%' }}>
              <i className="ti ti-vaccine" style={{ fontSize:40, color:'#fff' }} />
            </div>
          </div>
        </div>

        <h1 className="fade-up-2" style={{ fontFamily:'var(--font-display)', fontSize:42, color:'#fff', letterSpacing:'-0.5px', marginBottom:4, textAlign:'center' }}>
          Evitare<span style={{ color:'#1D9E75' }}>®</span>
        </h1>
        <p className="fade-up-3" style={{ fontSize:12, color:'rgba(255,255,255,0.4)', letterSpacing:'2px', textTransform:'uppercase', marginBottom:20 }}>Medical Center · Guadalajara</p>
        <p className="fade-up-4" style={{ fontFamily:'var(--font-display)', fontStyle:'italic', fontSize:22, color:'rgba(255,255,255,0.85)', textAlign:'center', lineHeight:1.4, marginBottom:10 }}>
          "Prevenir es vivir."
        </p>
        <p style={{ fontSize:13, color:'rgba(255,255,255,0.35)', textAlign:'center', maxWidth:280, lineHeight:1.6, marginBottom:48 }}>
          Más de 20 años cuidando la salud de las familias de Guadalajara, Jalisco
        </p>

        <div style={{ width:'100%', maxWidth:340, display:'flex', flexDirection:'column', gap:12 }}>
          <button className="btn btn-primary" style={{ width:'100%', padding:'15px', fontSize:15, background:'#1D9E75', borderRadius:14 }} onClick={() => setMode('register')}>
            <i className="ti ti-user-plus" /> Crear mi cuenta
          </button>
          <button className="btn btn-outline" style={{ width:'100%', padding:'15px', fontSize:15, borderColor:'rgba(255,255,255,0.25)', color:'#fff', borderRadius:14 }} onClick={() => setMode('login')}>
            <i className="ti ti-login" /> Ya tengo cuenta
          </button>
          <button onClick={handleDemo} style={{ background:'none', border:'none', color:'rgba(255,255,255,0.35)', fontSize:12, marginTop:4, cursor:'pointer', textDecoration:'underline' }}>
            Explorar sin cuenta (demo)
          </button>
        </div>
      </div>
      <p style={{ textAlign:'center', color:'rgba(255,255,255,0.2)', fontSize:11, padding:'0 20px 32px' }}>
        Av. Aztecas 290, Fracc. Monraz · 33 3813 2995
      </p>
    </div>
  )

  return (
    <div style={{ minHeight:'100dvh', display:'flex', flexDirection:'column', background:'var(--ev-surface)' }}>
      <div style={{ background:'var(--ev-dark)', padding:'52px 24px 28px' }}>
        <button onClick={() => setMode('welcome')} style={{ background:'none', border:'none', color:'rgba(255,255,255,0.5)', fontSize:13, display:'flex', alignItems:'center', gap:5, marginBottom:20, cursor:'pointer' }}>
          <i className="ti ti-arrow-left" /> Regresar
        </button>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ width:46, height:46, borderRadius:12, background:'#1D9E75', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <img src="/assets/logo-icon.jpg" alt="Evitare" style={{ width:36, height:36, borderRadius:8, objectFit:'cover' }} onError={e => e.target.style.display='none'} />
          </div>
          <div>
            <h2 style={{ fontFamily:'var(--font-display)', fontSize:22, color:'#fff' }}>{mode==='login'?'Bienvenido de vuelta':'Crear cuenta'}</h2>
            <p style={{ fontSize:12, color:'rgba(255,255,255,0.45)' }}>Evitare® Medical Center</p>
          </div>
        </div>
      </div>
      <div style={{ flex:1, padding:'24px', maxWidth:440, width:'100%', margin:'0 auto', display:'flex', flexDirection:'column', gap:14 }}>
        {mode==='register' && (
          <>
            <div><label style={{ fontSize:12, fontWeight:600, color:'var(--ev-text-muted)', display:'block', marginBottom:5 }}>Nombre completo *</label>
            <input className="input" placeholder="María González" value={form.name} onChange={e=>set('name',e.target.value)} /></div>
            <div><label style={{ fontSize:12, fontWeight:600, color:'var(--ev-text-muted)', display:'block', marginBottom:5 }}>Teléfono</label>
            <input className="input" placeholder="+52 33 1234 5678" value={form.phone} onChange={e=>set('phone',e.target.value)} /></div>
          </>
        )}
        <div><label style={{ fontSize:12, fontWeight:600, color:'var(--ev-text-muted)', display:'block', marginBottom:5 }}>Correo electrónico *</label>
        <input className="input" type="email" placeholder="correo@ejemplo.com" value={form.email} onChange={e=>set('email',e.target.value)} /></div>
        <div><label style={{ fontSize:12, fontWeight:600, color:'var(--ev-text-muted)', display:'block', marginBottom:5 }}>Contraseña *</label>
        <input className="input" type="password" placeholder="••••••••" value={form.password} onChange={e=>set('password',e.target.value)} /></div>

        {error && <div style={{ background:'var(--ev-danger-bg)', border:'1px solid #FBBCB8', borderRadius:8, padding:'10px 14px', fontSize:13, color:'var(--ev-danger)' }}><i className="ti ti-alert-circle"/> {error}</div>}

        <button className="btn btn-primary" style={{ width:'100%', padding:'15px', marginTop:4 }} onClick={handleAuth} disabled={loading}>
          {loading ? <span className="spinner" style={{ borderTopColor:'#fff' }}/> : mode==='login'?'Iniciar sesión':'Crear mi cuenta'}
        </button>
        <p style={{ textAlign:'center', fontSize:13, color:'var(--ev-text-muted)' }}>
          {mode==='login'?'¿No tienes cuenta?':'¿Ya tienes cuenta?'}{' '}
          <button onClick={() => setMode(mode==='login'?'register':'login')} style={{ background:'none', border:'none', color:'var(--ev-green)', fontWeight:600, fontSize:13, cursor:'pointer' }}>
            {mode==='login'?'Regístrate':'Inicia sesión'}
          </button>
        </p>
        <button onClick={handleDemo} style={{ background:'none', border:'none', color:'var(--ev-text-muted)', fontSize:12, cursor:'pointer', textDecoration:'underline', marginTop:4 }}>
          Continuar en modo demo
        </button>
      </div>
    </div>
  )
}
