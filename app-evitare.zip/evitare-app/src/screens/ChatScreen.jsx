import { useState, useRef, useEffect } from 'react'
import { ANTHROPIC_API_KEY, SYSTEM_PROMPT } from '../lib/data.js'

const QUICK = [
  '¿Qué vacunas tienen disponibles?',
  '¿Hacen servicio a domicilio?',
  '¿Cuál es el horario de atención?',
  '¿Qué es el Tamiz Neonatal?',
  '¿Qué vacunas necesita mi bebé?',
]

export default function ChatScreen({ user }) {
  const [messages, setMessages] = useState([
    {
      from: 'bot',
      text: `¡Hola ${user?.full_name?.split(' ')[0] || ''}! 👋 Soy el asistente de **Evitare® Medical Center**.\n\n*"Prevenir es vivir"*\n\n¿En qué puedo ayudarte hoy? Puedo orientarte sobre nuestras vacunas, servicios de tamiz, horarios y agendado de citas. 💉`,
      time: new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }),
    }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const endRef = useRef(null)

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const send = async (text) => {
    if (!text.trim() || loading) return
    const userMsg = { from: 'user', text, time: new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) }
    const updated = [...messages, userMsg]
    setMessages(updated)
    setInput('')
    setLoading(true)

    try {
      const apiKey = ANTHROPIC_API_KEY
      if (!apiKey) {
        await new Promise(r => setTimeout(r, 1000))
        const demoReplies = {
          'horario': 'Nuestro horario es:\n• **Lunes a Viernes:** 9:00 – 17:00\n• **Sábados:** 9:00 – 15:00\n\n📞 33 3813 2995 / 96\n📍 Av. Aztecas 290, Fracc. Monraz, Guadalajara',
          'domicilio': '¡Sí! 🏠 Contamos con **servicio a domicilio**.\n\nNuestro personal llega con gel antibacterial y equipo completamente desinfectado.\n\nPara solicitarlo:\n📱 WhatsApp: +52 33 3849 0551\n\n¿Te gustaría agendar una visita?',
          'vacunas': '💉 Nuestras **vacunas del mes** son:\n\n• SRP Triple Viral\n• Herpes Zóster\n• Gardasil 9 (VPH)\n• Rotavirus\n\nTambién contamos con vacunas para bebés, adultos y paquetes especiales. ¿Te interesa alguna en particular?',
          'tamiz': '🧬 El **Tamiz Neonatal** es una prueba que detecta enfermedades metabólicas en recién nacidos.\n\nEn Evitare® ofrecemos:\n• Tamiz básico\n• Tamiz auditivo\n• Tamiz 67 enfermedades\n\n¡La detección temprana salva vidas! ¿Quieres agendar una cita?',
          'bebé': '👶 Para tu bebé, las vacunas esenciales son:\n\n**Recién nacido:** Hepatitis B + BCG\n**2 meses:** Pentavalente + Neumococo + Rotavirus\n**4 meses:** Segunda dosis\n**12 meses:** SRP Triple Viral\n\nTenemos paquetes especiales. ¿Cuántos meses tiene tu bebé?',
        }
        const key = Object.keys(demoReplies).find(k => text.toLowerCase().includes(k))
        const reply = key ? demoReplies[key] : `Gracias por tu consulta sobre "${text}". En Evitare® estamos para ayudarte.\n\n📞 **33 3813 2995 / 96**\n📧 auxiliar@evitare.org\n\nNuestro equipo médico puede orientarte mejor. ¿Deseas agendar una cita? 😊`
        setMessages(p => [...p, { from: 'bot', text: reply, time: new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) }])
        setLoading(false)
        return
      }

      const conversationMsgs = updated.map(m => ({
        role: m.from === 'user' ? 'user' : 'assistant',
        content: m.text,
      }))

      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 500, system: SYSTEM_PROMPT, messages: conversationMsgs }),
      })
      const data = await res.json()
      const reply = data.content?.[0]?.text || 'Disculpa, ocurrió un error. Por favor llama al 33 3813 2995.'
      setMessages(p => [...p, { from: 'bot', text: reply, time: new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) }])
    } catch {
      setMessages(p => [...p, { from: 'bot', text: 'Disculpa, hubo un problema de conexión. Llámanos al **33 3813 2995** o escríbenos a auxiliar@evitare.org', time: new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) }])
    }
    setLoading(false)
  }

  const renderText = (text) => {
    return text.split('\n').map((line, i) => {
      let rendered = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\*(.*?)\*/g, '<em>$1</em>')
      return <p key={i} style={{ margin: '2px 0', lineHeight: 1.6 }} dangerouslySetInnerHTML={{ __html: rendered || '&nbsp;' }} />
    })
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100dvh', background: 'var(--ev-surface)' }}>
      {/* Header */}
      <div style={{ background: 'var(--ev-dark)', padding: '52px 20px 16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'linear-gradient(135deg, #1D9E75, #0B6B50)', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
            <i className="ti ti-message-chatbot" style={{ fontSize: 22, color: '#fff' }} />
            <div style={{ position: 'absolute', bottom: 0, right: 0, width: 12, height: 12, borderRadius: '50%', background: '#22C55E', border: '2px solid var(--ev-dark)' }} />
          </div>
          <div>
            <p style={{ fontSize: 15, fontWeight: 600, color: '#fff' }}>Asistente Evitare®</p>
            <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>● En línea · Respuesta inmediata</p>
          </div>
        </div>
      </div>

      {/* Mensajes */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: 'flex', flexDirection: m.from === 'user' ? 'row-reverse' : 'row', alignItems: 'flex-end', gap: 8 }}>
            {m.from === 'bot' && (
              <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--ev-green)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <i className="ti ti-vaccine" style={{ fontSize: 16, color: '#fff' }} />
              </div>
            )}
            <div style={{ maxWidth: '78%' }}>
              <div className={`chat-bubble ${m.from}`}>
                {renderText(m.text)}
              </div>
              <p style={{ fontSize: 10, color: 'var(--ev-text-muted)', marginTop: 3, textAlign: m.from === 'user' ? 'right' : 'left' }}>{m.time}</p>
            </div>
          </div>
        ))}

        {loading && (
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8 }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--ev-green)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <i className="ti ti-vaccine" style={{ fontSize: 16, color: '#fff' }} />
            </div>
            <div className="chat-bubble bot" style={{ display: 'flex', gap: 5, padding: '12px 16px', alignItems: 'center' }}>
              {[0, 0.2, 0.4].map((d, i) => <span key={i} style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--ev-text-muted)', display: 'inline-block', animation: `pulse 1s ${d}s infinite` }} />)}
            </div>
          </div>
        )}

        {/* Sugerencias rápidas */}
        {messages.length === 1 && !loading && (
          <div style={{ marginTop: 8 }}>
            <p style={{ fontSize: 12, color: 'var(--ev-text-muted)', marginBottom: 8 }}>Preguntas frecuentes:</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {QUICK.map(q => (
                <button key={q} onClick={() => send(q)} style={{ padding: '10px 14px', background: 'var(--ev-white)', border: '1px solid var(--ev-border)', borderRadius: 10, fontSize: 13, color: 'var(--ev-text)', cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <i className="ti ti-chevron-right" style={{ fontSize: 14, color: 'var(--ev-green)' }} />{q}
                </button>
              ))}
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Input */}
      <div style={{ padding: '12px 16px', background: 'var(--ev-white)', borderTop: '1px solid var(--ev-border)', flexShrink: 0, paddingBottom: 'calc(var(--nav-h) + 12px)' }}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
          <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input) } }} placeholder="Escribe tu consulta..." rows={1} style={{ flex: 1, resize: 'none', padding: '11px 14px', border: '1.5px solid var(--ev-border)', borderRadius: 12, fontSize: 14, color: 'var(--ev-text)', outline: 'none', fontFamily: 'var(--font-body)', lineHeight: 1.5, maxHeight: 100, overflowY: 'auto' }} onFocus={e => e.target.style.borderColor = 'var(--ev-green)'} onBlur={e => e.target.style.borderColor = 'var(--ev-border)'} />
          <button onClick={() => send(input)} disabled={!input.trim() || loading} style={{ width: 44, height: 44, borderRadius: 12, background: input.trim() && !loading ? 'var(--ev-green)' : 'var(--ev-border)', border: 'none', color: '#fff', cursor: input.trim() && !loading ? 'pointer' : 'not-allowed', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'background .2s' }}>
            <i className="ti ti-send" style={{ fontSize: 18 }} />
          </button>
        </div>
        <p style={{ fontSize: 11, color: 'var(--ev-text-muted)', marginTop: 6, textAlign: 'center' }}>
          Asistente IA · No reemplaza consulta médica
        </p>
      </div>
    </div>
  )
}
