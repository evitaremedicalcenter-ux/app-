import { useState } from 'react'
import LoginScreen from './screens/LoginScreen.jsx'
import HomeScreen from './screens/HomeScreen.jsx'
import CatalogScreen from './screens/CatalogScreen.jsx'
import LogbookScreen from './screens/LogbookScreen.jsx'
import AppointmentsScreen from './screens/AppointmentsScreen.jsx'
import ChatScreen from './screens/ChatScreen.jsx'
import ProfileScreen from './screens/ProfileScreen.jsx'

const NAV = [
  { id: 'home',         icon: 'ti-home',              label: 'Inicio' },
  { id: 'catalog',      icon: 'ti-vaccine',            label: 'Vacunas' },
  { id: 'appointments', icon: 'ti-calendar-plus',      label: 'Citas' },
  { id: 'logbook',      icon: 'ti-notebook',           label: 'Bitácora' },
  { id: 'chat',         icon: 'ti-message-chatbot',    label: 'Asistente' },
]

export default function App() {
  const [user, setUser]       = useState(null)
  const [screen, setScreen]   = useState('home')

  if (!user) return <LoginScreen onLogin={u => setUser(u)} />

  const navigate = (s) => setScreen(s)

  const renderScreen = () => {
    switch (screen) {
      case 'home':         return <HomeScreen user={user} onNavigate={navigate} />
      case 'catalog':      return <CatalogScreen onNavigate={navigate} />
      case 'appointments': return <AppointmentsScreen user={user} />
      case 'logbook':      return <LogbookScreen user={user} />
      case 'chat':         return <ChatScreen user={user} />
      case 'profile':      return <ProfileScreen user={user} onLogout={() => setUser(null)} />
      default:             return <HomeScreen user={user} onNavigate={navigate} />
    }
  }

  return (
    <div style={{ maxWidth: 430, margin: '0 auto', height: '100dvh', position: 'relative', background: 'var(--ev-surface)', boxShadow: '0 0 60px rgba(0,0,0,0.15)', overflow: 'hidden' }}>
      <div style={{ height: '100%', overflowY: 'auto', overflowX: 'hidden' }}>
        {renderScreen()}
      </div>

      {/* Bottom Navigation */}
      <nav className="bottom-nav">
        {NAV.map(n => (
          <button key={n.id} className={`nav-item ${screen === n.id ? 'active' : ''}`} onClick={() => setScreen(n.id)}>
            <i className={`ti ${n.icon}`} aria-hidden="true" />
            {n.label}
          </button>
        ))}
      </nav>
    </div>
  )
}
